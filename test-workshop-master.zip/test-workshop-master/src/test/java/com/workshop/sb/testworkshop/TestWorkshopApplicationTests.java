package com.workshop.sb.testworkshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestWorkshopApplicationTests {

	@Test
	void contextLoads() {
	}

}
