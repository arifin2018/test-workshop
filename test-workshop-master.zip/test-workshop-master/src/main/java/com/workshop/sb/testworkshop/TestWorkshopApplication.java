package com.workshop.sb.testworkshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestWorkshopApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestWorkshopApplication.class, args);
	}

}
